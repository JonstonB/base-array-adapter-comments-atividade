package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.adapter.CommentsAdapter;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;
import br.edu.fasam.mobile.meuprimeiroexemplo.model.Comments;

public class CommentsActivity extends DebugActivity {

    EditText txtPostId1;
    EditText txtNome1;
    EditText txtEmail1;
    EditText txtBody1;
    ListView listViewComments1;

    List<HashMap<String, String>> lista1 = new ArrayList<>();

    List<Comments> comentario = new ArrayList<>();
    //List<Post> postagens = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);
    }

    public void AdicionarComments(View view) {

        txtPostId1 = findViewById(R.id.txtPostId1);
        txtNome1 = findViewById(R.id.txtNome1);
        txtEmail1 = findViewById(R.id.txtEmail1);
        txtBody1 = findViewById(R.id.txtBody1);


        String postId, nome, email, body;
        postId = txtPostId1.getText().toString();
        nome = txtNome1.getText().toString();
        email = txtEmail1.getText().toString();
        body = txtBody1.getText().toString();

        //simpleAdapter(postId, nome, email, body);
        //arrayAdapter(postId, nome, email, body);
        baseAdapter(postId, nome, email, body);

    }

    private void preencherObjetoLista(String postId, String nome, String email, String body) {

        Integer idConvertido = Integer.parseInt(postId);
        Comments comments = Comments.builder().postId(idConvertido).nome(nome).email(email).body(body).build();

        comentario.add(comments);
    }

    /**
     * @param postId
     * @param nome
     * @param email
     * @param body
     */
    private void arrayAdapter (String postId, String nome, String email, String body) {
        preencherObjetoLista(postId, nome, email, body);

        listViewComments1 = findViewById(R.id.ListViewComments1);

        ArrayAdapter<Comments> arrayAdapter = new ArrayAdapter<Comments>(this,
                android.R.layout.simple_list_item_1, comentario);

        listViewComments1.setAdapter(arrayAdapter);
    }

    /**
     * @param postId
     * @param nome
     * @param email
     * @param body
     */
    private void baseAdapter (String postId, String nome, String email, String body) {

        try {

            preencherObjetoLista(postId, postId, email, body);

            listViewComments1 = findViewById(R.id.ListViewComments1);

            CommentsAdapter commentsAdapter = new CommentsAdapter(this, comentario);

            listViewComments1.setAdapter(commentsAdapter);

        }catch (Exception ex) {
            Toast.makeText(this, String.format("Ocorreu um erro: %s", ex.getMessage()), Toast.LENGTH_LONG).show();
        }

    }



    private void simpleAdapter(String postId, String nome, String email, String body) {
        HashMap<String, String> map = new HashMap<>();
        map.put("postId", postId);
        map.put("nome", nome);
        map.put("email", email);
        map.put("body", body);

        lista1.add(map);

        String[] from = {"userId", "nome", "email", "body"}; //chaves do seu Map
        int[] to = {R.id.txtItemPostId1, R.id.txtItemNome1, R.id.txtItemEmail1, R.id.txtItemBody1};

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, lista1, R.layout.item_comments, from, to);

        listViewComments1 = findViewById(R.id.ListViewComments1);
        listViewComments1.setAdapter(simpleAdapter);

        String dados;

        dados = String.format("Comments Adicionado");

        Toast.makeText(getApplicationContext(), dados, Toast.LENGTH_SHORT).show();
    }
}
