package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.adapter.PostAdapter;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;
import br.edu.fasam.mobile.meuprimeiroexemplo.model.Post;

public class PostActivity extends DebugActivity {

    EditText txtUserId;
    EditText txtTitle;
    EditText txtBody;
    ListView listViewPost;

    //SimpleAdapter = trabalha com um List<HashMap>
    List<HashMap<String, String>> lista = new ArrayList<>(); //Pega a lista de dados enviada pelo usuário

    //ArrayAdapter = trabalha apenas com a lista de obejto preterido. (Post)
    List<Post> postagens = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
    }

    public void adicionarPost(View view) {

        //ENTRADA
        txtUserId = findViewById(R.id.txtUserId);
        txtTitle = findViewById(R.id.txtTitle);
        txtBody = findViewById(R.id.txtBody);

        //PROCESSAMENTO
        String userId, title, body;
        userId = txtUserId.getText().toString();
        title = txtTitle.getText().toString();
        body = txtBody.getText().toString();


        //simpleAdapter(userId, title, body);

        //arrayAdapter(userId, title, body);

        baseAdapter(userId, title, body);

    }

    /**
     * BaseAdapter método responsável para exibir registro de forma customizada e enxuta (prática)
     * @param userId
     * @param title
     * @param body
     */
    private void baseAdapter (String userId, String title, String body) {

        try {

            preencherObjetoLista(userId, title, body);

            listViewPost = findViewById(R.id.ListViewPost);

            PostAdapter postAdapter = new PostAdapter(this, postagens);

            listViewPost.setAdapter(postAdapter);

        }catch (Exception ex) {
            Toast.makeText(this, String.format("Ocorreu um erro: %s", ex.getMessage()), Toast.LENGTH_LONG).show();
        }

    }

    /**
     * ArrayAdapter trabalha com a uma lista 'tipada'
     * @param userId
     * @param title
     * @param body
     */

    private void arrayAdapter (String userId, String title, String body) {
        preencherObjetoLista(userId, title, body);

        //Procurar referência da listView na tela desta Atividade para imprimir os dados na lista
        listViewPost = findViewById(R.id.ListViewPost);

        //Imprimir o ArrayAdapter
        ArrayAdapter<Post> arrayAdapter = new ArrayAdapter<Post>(this,
                android.R.layout.simple_list_item_1, postagens);

        listViewPost.setAdapter(arrayAdapter);
    }

    private void preencherObjetoLista(String userId, String title, String body) {
        //criar objeto
        Integer idConvertido = Integer.parseInt(userId);
        Post post = Post.builder().userId(idConvertido).title(title).body(body).build();

        //Add o objeto na lista de post
        postagens.add(post);
    }

    private void simpleAdapter(String userId, String title, String body) {
        //AGORA VAMOS INICIAR OS TRABALHOS PARA O SimpleAdapter
        //SimpleAdapter PRECISA DE UM LINK<? EXTENDS HasMap<String, ?>>
        /*
        List<String> bla = new ArrayList<>(); //List trabalha com indice numerico
        bla.add(""); //0
        bla.add(""); //1
        bla.add(""); //2
        bla.add(""); //3
        bla.add(""); //4

        HashMap<String, String> mapExemplo= new HashMap<>(); //HashMap trabalha com indice 'associativo', geralmente
        mapExemplo.put("Index 1", "Valor 1");
        mapExemplo.put("Index 2", "Valor 2");
        mapExemplo.put("Index 3", "Valor 3");
        mapExemplo.put("Index 4", "Valor 4");

        mapExemplo.get("index 3");
       */

        HashMap<String, String> map = new HashMap<>(); //Armazena as informações do usuário num MAP (Mapa de Valores)
        map.put("userId", userId);
        map.put("title",title);
        map.put("body", body);

        lista.add(map);
        //SimpleAdapter (Context, context, List<? extends Map<String, ?>>, data
        // int resource, String[], from, int[] to)
        //Mapear o layout do tipo "item" com os dados contidos do List<HashMap<String, String>>

        //SAIDA
        String[] from = {"userId", "title", "body"}; //chaves do seu Map
        int[] to = {R.id.txtItemUserId, R.id.txtItemTitle, R.id.txtItemBody}; //ids do layout do tipo "item"

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, lista, R.layout.item_post, from, to);

        //Procurar a referencia da ListView para que essa possa imprimir os dados utilizando o padrão ADAPTER

        listViewPost = findViewById(R.id.ListViewPost);
        listViewPost.setAdapter(simpleAdapter);
    }
}