package br.edu.fasam.mobile.meuprimeiroexemplo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.model.Comments;

public class CommentsAdapter extends BaseAdapter {

    private Context context1;
    private List<Comments> comentario;

    public CommentsAdapter(Context context1, List<Comments> comentario) {

        this.context1 = context1;
        this.comentario = comentario;
    }
    @Override
    public int getCount() {
        return this.comentario!=null ? this.comentario.size() : 0;
    }

    @Override
    public Object getItem(int i) {
        return this.comentario.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int posicao, View view, ViewGroup viewGroup) {

        if(view == null) {
            view = LayoutInflater.from(context1)
                    .inflate(R.layout.item_comments, viewGroup, false);
        }

        Comments comments = (Comments) getItem(posicao);

        TextView txtItemPostId1, txtItemNome1, txtItemEmail1, txtItemBody1;

        txtItemPostId1 = view.findViewById(R.id.txtItemPostId1);
        txtItemNome1 = view.findViewById(R.id.txtItemNome1);
        txtItemEmail1 = view.findViewById(R.id.txtItemEmail1);
        txtItemBody1 = view.findViewById(R.id.txtItemBody1);

        txtItemPostId1.setText(String.valueOf(comments.getPostId()));
        txtItemNome1.setText(comments.getNome());
        txtItemEmail1.setText(comments.getEmail());
        txtItemBody1.setText(comments.getBody());

        return view;
    }
}
