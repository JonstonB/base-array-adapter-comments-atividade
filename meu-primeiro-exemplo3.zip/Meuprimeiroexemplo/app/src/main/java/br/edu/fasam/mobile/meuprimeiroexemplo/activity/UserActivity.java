package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;

public class UserActivity extends DebugActivity {

    EditText txtNome;
    EditText txtSobrenome;
    EditText editTextTextEmailAddress;
    EditText editTextPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
    }

    public void Exibir(View view) {
    }

}