package br.edu.fasam.mobile.meuprimeiroexemplo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.model.Post;

public class PostAdapter extends BaseAdapter {

    private Context context;
    private List<Post> postagens;
    //private LayoutInflater inflater;

    public PostAdapter(Context context, List<Post> postagens) {

        this.context = context;
        this.postagens = postagens;
        //this.inflater = inflater;
    }
    @Override
    public int getCount() {
        return this.postagens!=null ? this.postagens.size() : 0;
    }

    @Override
    public Object getItem(int i) {
        return this.postagens.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int posicao, View view, ViewGroup viewGroup) {

        //Verificar o Layout está instaciado, senão leia a referência do xml para o objeto

        if(view == null) {
            view = LayoutInflater.from(context)
                    .inflate(R.layout.item_post, viewGroup, false);
        }

        //Procurar o item dentro da lista para ser exibido na listview
        Post post = (Post) getItem(posicao);

        //Criar a referencia de atributos/objeto java para ser customizar uma listView
        TextView txtItemUserId, txtItemTitle, txtItemBody;

        txtItemUserId = view.findViewById(R.id.txtItemUserId);
        txtItemTitle = view.findViewById(R.id.txtItemTitle);
        txtItemBody = view.findViewById(R.id.txtItemBody);

        txtItemUserId.setText(String.valueOf(post.getUserId()));
        txtItemTitle.setText(post.getTitle());
        txtItemBody.setText(post.getBody());

        return view;
    }
}
